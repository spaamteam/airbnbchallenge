
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.10.1'
version = '1.10.1'
full_version = '1.10.1'
git_revision = 'f769c64026f5ff993ec1e28cbd9f39b8da75347d'
release = True

if not release:
    version = full_version
