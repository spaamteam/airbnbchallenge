
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.10.2'
version = '1.10.2'
full_version = '1.10.2'
git_revision = '5667fbafb5d84e3a412a07aac72c769baa590579'
release = True

if not release:
    version = full_version
